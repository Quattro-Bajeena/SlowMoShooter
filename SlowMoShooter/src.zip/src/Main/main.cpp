#include "stdafx.h"
#include "Main/Game.h"


int main()
{
    Game game;
    game.Run();
    return 0;
}