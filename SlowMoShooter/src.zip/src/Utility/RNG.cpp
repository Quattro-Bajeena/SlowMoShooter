#include "stdafx.h"
#include "RNG.h"
